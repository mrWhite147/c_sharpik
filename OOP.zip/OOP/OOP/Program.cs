﻿using System;
using System.Collections.Generic;
using System.IO;

namespace MyApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Mains mains = new Mains();
            User currentUser = null;
            string put = "C:\\OOP\\ooo.txt";
            mains.Upload(put);
            while (true)
            {
                Console.WriteLine("Добро пожаловать в библиотеку");
                Console.WriteLine("1. Войти");
                Console.WriteLine("2. Зарегистририроваться");
                Console.WriteLine("3. Выйти");
                string zov = Console.ReadLine();
                switch (zov)
                {
                    case "1":
                        Console.WriteLine("Введите логин и пароль: ");
                        currentUser = mains.Login();
                        if (currentUser != null)
                        {
                            mains.ShowMenu(currentUser);
                        }
                        break;

                    case "2":
                        mains.RegistrationUser();
                        break;

                    case "3":
                        mains.Save(put);
                        return;
                    default:
                        Console.WriteLine("ХЗАПХВАПЗХАВПЗХ Боже челл..... Введи цифру от 1 до 3 йоу");
                        break;
                }
            }
        }
    }
    // User
    public abstract class User
    {
        public string Login { get; set; }
        public string Password { get; set; }
        public List<int> UserBooks { get; set; } = new List<int>();

        protected User(string login, string password)
        {
            Login = login;
            Password = password;
        }
        public abstract void ShowMenu(Mains mains);
    }
    public class uUser : User
    {
        public uUser(string login, string password) : base(login, password) { }

        public override void ShowMenu(Mains mains)
        {
            while (true)
            {
                Console.WriteLine("\nМеню пользователя:");
                Console.WriteLine("1 - Просмотреть доступные книги");
                Console.WriteLine("2 - Взять книгу");
                Console.WriteLine("3 - Вернуть книгу");
                Console.WriteLine("4 - Просмотреть мои книги");
                Console.WriteLine("5 - Выйти");
                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        mains.ShowBooks();
                        break;
                    case "2":
                        Console.WriteLine("Введите ID книги, которую вы хотите узнать");
                        if (int.TryParse(Console.ReadLine(), out int idV))
                        {
                            mains.TakeBook(this, idV);
                        }    
                        else
                        {
                            Console.WriteLine("Неверный ID, попробуйте снова");
                        }
                        break;

                    case "3":
                        Console.WriteLine("Введите ID книги, которую вы хотите вернуть");
                        if (int.TryParse(Console.ReadLine(), out int idO))
                        {
                            mains.ReturnBook(this, idO);
                        }
                        else
                        {
                            Console.WriteLine("Неверный ID, попробуйте снова");
                        }
                        break;

                    case "4":
                        Console.WriteLine("Ваши книги: ");
                        foreach (var bookId in UserBooks)
                        {
                            var book = mains.FindBook(bookId);
                            if (book != null)
                            {
                                book.Info();
                            }
                        }
                        break;

                    case "5":
                        return;
                    default:
                        Console.WriteLine("Ну может цифру выберешь от 1 до 5");
                        break;
                }
            }
        }
    }
    public class Librarian : User
    {
        public Librarian(string login, string password) : base(login, password) { }
        public override void ShowMenu(Mains mains)
        {
            while (true)
            {
                Console.WriteLine("\nМеню библиотекаря:");
                Console.WriteLine("1. Добавить книгу");
                Console.WriteLine("2. Удалить книгу");
                Console.WriteLine("3. Зарегистрировать нового пользователя");
                Console.WriteLine("4. Зарегистрировать нового библиотекаря");
                Console.WriteLine("5. Просмотреть список всех пользователей");
                Console.WriteLine("6. Просмотреть список всех книг");
                Console.WriteLine("7. Выйти");
                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        Console.WriteLine("Введите название книги: ");
                        string bookName = Console.ReadLine();
                        Console.WriteLine("");
                        string bookAuthor = Console.ReadLine();
                        mains.AddBook(new Books() { Name = bookName, Author = bookAuthor });
                        break;

                    case "2":
                        Console.WriteLine("Введите ID книги для удаления: ");
                        if (int.TryParse(Console.ReadLine(), out int idD))
                        {
                            mains.RemoveBook(idD);
                        }
                        else
                        {
                            Console.WriteLine("Неверный ID, попробуйте ещё раз");
                        }
                        break;

                    case "3":
                        mains.RegistrationUser();
                        break;

                    case "4":
                        mains.RegistrationLibrarian();
                        break;

                    case "5":
                        mains.ShowUsers(); 
                        break;

                    case "6":
                        mains.ShowBooks();
                        break;

                    case "7":
                        return;
                    default:
                        Console.WriteLine("Наверно тяжело выбрать цифру от 1 до 7");
                        break;

                }
            }
        }
    }
    // Класс книг
    public abstract class Book
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool Status { get; set; } = true;
        public string Author { get; set; }
        public abstract void Info();
    }
    public class Books : Book
    {
        public override void Info()
        {
            Console.WriteLine($"ID: {Id}, Книга: {Name}, Автор: {Author}, Статус: " + $"{(Status ? "Доступна" : "Выдана")}");
        }
    }
        // Main
        public class Mains
        {
            public List<Book> Books { get; set; } = new List<Book>();
            public List<User> Users { get; set; } = new List<User>();
            private int IdPlus = 1; // Счетчик ID

            public Mains()
            {
                Users.Add(new Librarian("asd", "asd"));
                Users.Add(new uUser("zxc", "123"));
            }
            public User Login()
                {
                Console.WriteLine();
                string login = Console.ReadLine();
                Console.WriteLine();
                string password = Console.ReadLine();

            foreach (var user in Users)
            {
                if (user.Login == login && user.Password == password)
                {
                    Console.WriteLine("Вы успешно зашли");
                    return user;
                }
            }
            Console.WriteLine("Неверный логин или пароль. Введите снова.");
            return null;
        }
        // Регистрация user
        public void RegistrationUser()
        {
            Console.WriteLine("Введите логин: ");
            string login = Console.ReadLine();
            Console.WriteLine("Введите пароль: ");
            string password = Console.ReadLine();

            Users.Add(new uUser(login, password));
            Console.WriteLine("Зарегистрирован.");
        }
        // Регистрация librarian
        public void RegistrationLibrarian()
        {
            Console.WriteLine("Введите логин: ");
            string login = Console.ReadLine();
            Console.WriteLine("Введите пароль: ");
            string password = Console.ReadLine();

            Users.Add(new Librarian(login, password));
            Console.WriteLine("Зарегистрирован.");
        }
        // Меню
        public void ShowMenu(User user)
        {
            user.ShowMenu(this);
        }
        public Book FindBook(int id)
        {
            foreach (var book in Books)
            {
                if (book.Id == id)
                {
                    return book;
                }
            }
            return null;
        }
        // Добавление книги
        public void AddBook(Books book)
        {
            book.Id = IdPlus++;
            Books.Add(book);
            Console.WriteLine("Книга добавлена");
        }
        // Удаление книги
        public void RemoveBook(int id)
        {
            Book bookFind = FindBook(id);
            if (bookFind != null)
            {
                Books.Remove(bookFind);
                Console.WriteLine("Книга удалена");
            }
            else
            {
                Console.WriteLine("Книга не найдена");
            }
        }
        // Взятие книги
        public void TakeBook(User user, int id)
        {
            Book book = FindBook(id);
            if (book != null && book.Status)
            {
                book.Status = false;
                user.UserBooks.Add(book.Id);
                Console.WriteLine($"Вы взяли: {book.Name}");
            }
            else
            {
                Console.WriteLine("Книгу кто-то взял или её нет");
            }
        }
        // Возврат книги
        public void ReturnBook(User user, int id)
        {
            Book book = FindBook(id);
            if (book != null && !book.Status && user.UserBooks.Contains(book.Id))
            {
                book.Status = true;
                user.UserBooks.Remove(book.Id);
                Console.WriteLine($"Вы вернули: {book.Name}");
            }
            else
            {
                Console.WriteLine("Ты наверно чото попутал.");
            }
        }
        // Показ всех пользователй
        public void ShowUsers()
        {
            Console.WriteLine("Все пользователи");
            foreach (var user in Users)
            {
                Console.WriteLine($"Логин: {user.Login}, Роль: {(user is Librarian ? "Библиотекарь" : "Пользователь")}");
            }
        }
        // Показ всех книг
        public void ShowBooks()
        {
            Console.WriteLine("Все книги библиотеки: ");
            foreach(var book in Books)
            {
                book.Info();
            }
        }
        // Сохранение данных
        public void Save(string put)
        {
            using (StreamWriter writer = new StreamWriter(put))
            {
                foreach (var book in Books)
                {
                    writer.WriteLine($"Книги: {book.Id},{book.Name},{book.Author},{(book.Status ? "Доступна" : "Выдана")}");
                }

                foreach (var user in Users)
                {
                    string role = (user is Librarian) ? "Библиотекарь" : "Пользователь";
                    string userBooks = string.Join(",", user.UserBooks);
                    writer.WriteLine($"Пользователи: Логин-{user.Login} Пароль-{user.Password} Роль-{role} Взятые книги: {userBooks}");
                }
            }
        }
        // Загрузка данных
        public void Upload(string path)
        {
            using (StreamReader reader = new StreamReader(path))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string[] parts = line.Split(',');
                    if (parts[0] == "Книга")
                    {
                        Books.Add(new Books() { Name = parts[2], Author = parts[3], Id = int.Parse(parts[1]), Status = parts[4] == "Доступна" });
                    }
                    else if (parts[0] == "Пользователь")
                    {
                        if (parts[3] == "Библиотекарь")
                        {
                            Users.Add(new Librarian(parts[1], parts[2]));
                        }
                        else
                        {
                            Users.Add(new uUser(parts[1], parts[2]));
                        }
                    }
                }
            }
        }
    }
}
